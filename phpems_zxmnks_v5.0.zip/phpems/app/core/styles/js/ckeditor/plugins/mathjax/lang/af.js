/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'af', {
	title: 'Wiskunde in TeX',
	button: 'Wiskunde',
	dialogInput: 'Skryf you Tex hier',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX dokument',
	loading: 'laai...',
	pathName: 'wiskunde'
} );
