/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'sl', {
	title: 'Matematika v TeX',
	button: 'Matematika',
	dialogInput: 'Napišite svoj TeX tukaj',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX dokumentacija',
	loading: 'nalaganje...',
	pathName: 'matematika'
} );
