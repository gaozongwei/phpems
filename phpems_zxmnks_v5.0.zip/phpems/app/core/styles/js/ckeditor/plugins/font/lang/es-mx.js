/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'es-mx', {
	fontSize: {
		label: 'Tamaño',
		voiceLabel: 'Tamaño de letra',
		panelTitle: 'Tamaño de letra'
	},
	label: 'Letra',
	panelTitle: 'Nombre de letra',
	voiceLabel: 'Letra'
} );
